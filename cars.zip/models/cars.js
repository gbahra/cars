module.exports = [
  {
    id: 0,
    name: "Aston Martin DB7",
    price: 29999.99,
    condition: "Used",
    year: 2005,
    body: "Coupe",
    color: "British Racing Green"
  },
  {
    id: 1,
    name: "Mini One",
    price: 3499.99,
    condition: "Used",
    year: 2008,
    body: "Hatchback",
    color: "Pistachio Green"
  },
  {
    id: 2,
    name: "Nissan GT-R",
    price: 79999.99,
    condition: "New",
    year: 2017,
    body: "Coupe",
    color: "Acid Green"
  },
  {
    id: 3,
    name: "Volvo V70",
    price: 9999.99,
    condition: "Used",
    year: 2011,
    body: "Estate",
    color: "Dull Green"
  },
  {
    id: 4,
    name: "Ford Mustang",
    price: 39999.00,
    condition: "New",
    year: 2017,
    body: "Coupe",
    color: "American Green"
  }
]
